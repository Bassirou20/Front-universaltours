import React, { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { api } from '../../lib/axios'
import { Modal } from '../../ui/Modal'
import { ConfirmDialog } from '../../ui/ConfirmDialog'
import { T, Th, Td } from '../../ui/Table'
import { Pagination } from '../../ui/Pagination'
import { FiltersBar } from '../../ui/FiltersBar'
import { ReservationDetails } from './ReservationDetails'
import { ReservationsForm, ReservationInput } from './ReservationsForm'
import { useToast } from '../../ui/Toasts'
import { Eye } from 'lucide-react'

export default function ReservationsPage() {
  const qc = useQueryClient()
  const toast = useToast()

  const [page, setPage] = useState(1)
  const [perPage] = useState(10)
  const [search, setSearch] = useState('')
  const [detailsOpen, setDetailsOpen] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  const [selected, setSelected] = useState<any | null>(null)
  const [confirmId, setConfirmId] = useState<number | null>(null)

  /* ================= QUERY ================= */

  const q = useQuery({
    queryKey: ['reservations', { page, perPage, search }],
    queryFn: async () => {
      const res = await api.get('/reservations', {
        params: {
          page,
          per_page: perPage,
          search,
        },
      })
      return res.data
    },
  })

  /* ================= MUTATIONS ================= */

  const mDelete = useMutation({
    mutationFn: (id: number) => api.delete(`/reservations/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['reservations'] })
      toast.push({ title: 'Réservation supprimée', tone: 'success' })
    },
  })

  const mCreate = useMutation({
    mutationFn: (vals: ReservationInput) => api.post('/reservations', vals),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['reservations'] })
      setEditOpen(false)
      toast.push({ title: 'Réservation créée', tone: 'success' })
    },
  })

  const mUpdate = useMutation({
    mutationFn: (vals: ReservationInput) =>
      api.put(`/reservations/${selected?.id}`, vals),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['reservations'] })
      setEditOpen(false)
      toast.push({ title: 'Réservation mise à jour', tone: 'success' })
    },
  })

  /* ================= DATA ================= */

  // 🔴 FIX PRINCIPAL : Laravel retourne "data", pas "items"
  const reservations = q.data?.data ?? []

  /* ================= UI ================= */

  return (
    <div className="space-y-4">
      {/* ===== HEADER ===== */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Réservations</h2>
        <button
          className="btn-primary"
          onClick={() => {
            setSelected(null)
            setEditOpen(true)
          }}
        >
          Nouvelle réservation
        </button>
      </div>

      {/* ===== FILTERS ===== */}
      <FiltersBar>
        <div>
          <label className="label">Recherche</label>
          <input
            className="input"
            placeholder="Référence, client..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </FiltersBar>

      {/* ===== TABLE ===== */}
      {q.isLoading ? (
        <p>Chargement…</p>
      ) : (
        <T>
          <thead className="bg-gray-100/70 dark:bg-white/5">
            <tr>
              <Th>Référence</Th>
              <Th>Client</Th>
              <Th>Statut</Th>
              <Th>Total</Th>
              <Th>Actions</Th>
            </tr>
          </thead>
          <tbody>
            {reservations.length === 0 ? (
              <tr>
                <Td colSpan={5} className="text-center py-6 text-gray-500">
                  Aucune réservation trouvée
                </Td>
              </tr>
            ) : (
              reservations.map((r: any) => (
                <tr
                  key={r.id}
                  className="border-t border-black/5 dark:border-white/10"
                >
                  <Td>{r.reference}</Td>
                  <Td>{r.client?.nom ?? '—'}</Td>
                  <Td>{r.statut}</Td>
                  <Td>{r.montant_total?.toLocaleString()} XOF</Td>
                  <Td>
                    <div className="flex gap-2 justify-end">
                      <button
                        className="btn px-2 bg-blue-100 text-blue-700 flex items-center gap-1"
                        onClick={() => {
                          setSelected(r)
                          setDetailsOpen(true)
                        }}
                      >
                        <Eye size={16} /> Voir
                      </button>

                      <button
                        className="btn px-2 bg-gray-200 dark:bg-white/10"
                        onClick={() => {
                          setSelected(r)
                          setEditOpen(true)
                        }}
                      >
                        Modifier
                      </button>

                      <button
                        className="btn px-2 bg-red-600 text-white"
                        onClick={() => setConfirmId(r.id)}
                      >
                        Supprimer
                      </button>
                    </div>
                  </Td>
                </tr>
              ))
            )}
          </tbody>
        </T>
      )}

      {/* ===== PAGINATION ===== */}
      <Pagination
        page={q.data?.current_page ?? 1}
        lastPage={q.data?.last_page ?? 1}
        total={q.data?.total}
        onPage={setPage}
      />

      {/* ===== DETAILS ===== */}
      <Modal
        open={detailsOpen}
        onClose={() => setDetailsOpen(false)}
        title="Détails de la réservation"
        widthClass="max-w-4xl"
      >
        {selected && <ReservationDetails reservation={selected} />}
      </Modal>

      {/* ===== FORM ===== */}
      <Modal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        title={selected ? 'Modifier réservation' : 'Nouvelle réservation'}
        widthClass="max-w-4xl"
      >
        <ReservationsForm
          defaultValues={selected ?? undefined}
          onSubmit={(vals) =>
            selected ? mUpdate.mutate(vals) : mCreate.mutate(vals)
          }
          onCancel={() => setEditOpen(false)}
          submitting={mCreate.isPending || mUpdate.isPending}
        />
      </Modal>

      {/* ===== CONFIRM DELETE ===== */}
      <ConfirmDialog
        open={confirmId !== null}
        onCancel={() => setConfirmId(null)}
        onConfirm={() => {
          if (confirmId) mDelete.mutate(confirmId)
          setConfirmId(null)
        }}
        title="Supprimer cette réservation ?"
        message="Cette action est irréversible."
      />
    </div>
  )
}
