import React, { useEffect } from 'react'
import { useForm } from 'react-hook-form'

/* ================= TYPES ================= */

export type ReservationType =
  | 'hotel'
  | 'billet_avion'
  | 'voiture'
  | 'evenement'

export type ReservationInput = {
  client_id: number
  type: ReservationType

  date_debut?: string
  date_fin?: string

  montant_total: number
  devise: string
  statut?: string

  /* HOTEL */
  hotel_nom?: string
  nombre_nuits?: number
  nombre_personnes?: number

  /* BILLET AVION */
  ville_depart?: string
  ville_arrivee?: string
  date_depart?: string
  date_retour?: string
  compagnie?: string

  /* VOITURE */
  lieu_prise?: string
  lieu_retour?: string
  type_voiture?: string

  /* EVENEMENT */
  forfait_id?: number
}

/* ================= PROPS ================= */

type Props = {
  defaultValues?: Partial<ReservationInput>
  onSubmit: (vals: ReservationInput) => void
  onCancel: () => void
  submitting?: boolean
}

/* ================= COMPONENT ================= */

export const ReservationsForm: React.FC<Props> = ({
  defaultValues,
  onSubmit,
  onCancel,
  submitting
}) => {
  const {
    register,
    watch,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm<ReservationInput>({
    defaultValues: {
      devise: 'XOF',
      statut: 'en_attente',
      ...defaultValues
    }
  })

  const type = watch('type')
  
  useEffect(() => {
    if (defaultValues) reset(defaultValues)
  }, [defaultValues, reset])

  /* ================= UI ================= */

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="space-y-6 p-4 max-w-3xl mx-auto"
    >
      {/* ===== SECTION GÉNÉRALE ===== */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <input
          {...register('client_id', { required: true })}
          type="number"
          placeholder="Client ID"
          className="input"
        />

        <select {...register('type', { required: true })} className="input">
          <option value="">Type de réservation</option>
          <option value="hotel">Hôtel</option>
          <option value="billet_avion">Billet avion</option>
          <option value="voiture">Voiture</option>
          <option value="evenement">Événement / Forfait</option>
        </select>
      </div>

      {/* ===== CHAMPS COMMUNS ===== */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <input {...register('date_debut')} type="date" className="input" />
        <input {...register('date_fin')} type="date" className="input" />
        <input
          {...register('montant_total', { required: true })}
          type="number"
          placeholder="Montant total"
          className="input"
        />
      </div>

      {/* ===== HOTEL ===== */}
      {type === 'hotel' && (
        <div className="card">
          <h3 className="title">Détails Hôtel</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input {...register('hotel_nom')} placeholder="Nom de l'hôtel" className="input" />
            <input {...register('nombre_nuits')} type="number" placeholder="Nuits" className="input" />
            <input {...register('nombre_personnes')} type="number" placeholder="Personnes" className="input" />
          </div>
        </div>
      )}

      {/* ===== BILLET AVION ===== */}
      {type === 'billet_avion' && (
        <div className="card">
          <h3 className="title">Détails Vol</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input {...register('ville_depart')} placeholder="Ville départ" className="input" />
            <input {...register('ville_arrivee')} placeholder="Ville arrivée" className="input" />
            <input {...register('date_depart')} type="date" className="input" />
            <input {...register('date_retour')} type="date" className="input" />
            <input {...register('compagnie')} placeholder="Compagnie" className="input md:col-span-2" />
          </div>
        </div>
      )}

      {/* ===== VOITURE ===== */}
      {type === 'voiture' && (
        <div className="card">
          <h3 className="title">Détails Location</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input {...register('lieu_prise')} placeholder="Lieu de prise" className="input" />
            <input {...register('lieu_retour')} placeholder="Lieu de retour" className="input" />
            <input {...register('type_voiture')} placeholder="Type de voiture" className="input" />
          </div>
        </div>
      )}

      {/* ===== EVENEMENT ===== */}
      {type === 'evenement' && (
        <div className="card">
          <h3 className="title">Forfait / Événement</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input {...register('forfait_id')} type="number" placeholder="Forfait ID" className="input" />
            <input {...register('nombre_personnes')} type="number" placeholder="Personnes" className="input" />
          </div>
        </div>
      )}

      {/* ===== ACTIONS ===== */}
      <div className="flex justify-end gap-3 pt-4">
        <button type="button" onClick={onCancel} className="btn-outline">
          Annuler
        </button>
        <button type="submit" disabled={submitting} className="btn-primary">
          {submitting ? 'Enregistrement...' : 'Enregistrer'}
        </button>
      </div>
    </form>
  )
}
