import React from 'react'
import { BadgeCheck, CalendarClock, UserRound, ShoppingCart, Receipt, Info, Clock } from 'lucide-react'

export type ReservationDetailsModel = {
  id: number
  reference?: string
  statut?: 'brouillon' | 'confirmee' | 'annulee'
  montant_total?: number
  montant_sous_total?: number
  montant_taxes?: number
  devise?: string
  created_at?: string
  client?: { nom?: string; prenom?: string }
  lignes?: Array<{
    id: number
    designation: string
    quantite: number
    prix_unitaire: number
    taxe?: number
    total_ligne?: number
    produit?: { nom?: string; type?: string }
  }>
  notes?: string | null
}

const ToneBadge: React.FC<{ children: React.ReactNode; tone?: 'green'|'red'|'amber'|'gray' }> = ({ children, tone='gray' }) => {
  const tones: Record<string,string> = {
    green: 'bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300',
    red: 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300',
    amber: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300',
    gray: 'bg-gray-100 text-gray-700 dark:bg-white/10 dark:text-gray-200',
  }
  return <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${tones[tone]}`}>{children}</span>
}

const toneForStatus = (s?: string) => s==='confirmee' ? 'green' : s==='annulee' ? 'red' : 'amber'

export const ReservationDetails: React.FC<{ reservation: ReservationDetailsModel }> = ({ reservation }) => {
  const devise = reservation.devise || 'XOF'
  const fmt = (n?: number) => (Number(n || 0)).toLocaleString() + ' ' + devise
  const date = reservation.created_at ? new Date(reservation.created_at).toLocaleString() : '—'

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-base md:text-lg font-semibold">Réservation {reservation.reference || `#${reservation.id}`}</div>
          <div className="flex flex-wrap items-center gap-2 mt-1">
            <ToneBadge tone={toneForStatus(reservation.statut)}>{reservation.statut || 'brouillon'}</ToneBadge>
            <ToneBadge tone="gray">Créée le {date}</ToneBadge>
          </div>
        </div>
        <div className="hidden md:flex gap-2">
          <span className="inline-flex items-center gap-1 text-sm px-2.5 py-1 rounded-xl bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300">
            <Receipt size={16}/> Total {fmt(reservation.montant_total)}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white dark:bg-panel p-4 space-y-2">
          <div className="text-sm font-semibold mb-1 flex items-center gap-2"><UserRound size={16}/> Client</div>
          <div className="text-sm">{[reservation?.client?.nom, reservation?.client?.prenom].filter(Boolean).join(' ') || '—'}</div>
        </div>

        <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white dark:bg-panel p-4 space-y-2">
          <div className="text-sm font-semibold mb-1 flex items-center gap-2"><Receipt size={16}/> Montants</div>
          <div className="text-sm">Sous-total : {fmt(reservation.montant_sous_total)}</div>
          <div className="text-sm">Taxes : {fmt(reservation.montant_taxes)}</div>
          <div className="text-sm font-semibold">Total : {fmt(reservation.montant_total)}</div>
        </div>

        <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white dark:bg-panel p-4 space-y-2">
          <div className="text-sm font-semibold mb-1 flex items-center gap-2"><Info size={16}/> Infos</div>
          <div className="text-sm">Devise : {devise}</div>
          <div className="text-sm">Statut : {reservation.statut || 'brouillon'}</div>
          <div className="text-sm">Créée : {date}</div>
        </div>
      </div>

      <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white dark:bg-panel p-4">
        <div className="flex items-center gap-2 mb-3"><ShoppingCart size={16}/> <div className="text-sm font-semibold">Lignes</div></div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[720px]">
            <thead className="text-left">
              <tr className="border-b border-black/5 dark:border-white/10">
                <th className="p-2">Produit</th>
                <th className="p-2">Désignation</th>
                <th className="p-2">Qté</th>
                <th className="p-2">PU</th>
                <th className="p-2">Taxe</th>
                <th className="p-2">Total</th>
              </tr>
            </thead>
            <tbody>
              {(reservation.lignes ?? []).map((l) => (
                <tr key={l.id} className="border-t border-black/5 dark:border-white/10">
                  <td className="p-2">{l.produit?.nom || l.produit?.type || '—'}</td>
                  <td className="p-2">{l.designation}</td>
                  <td className="p-2">{l.quantite}</td>
                  <td className="p-2">{fmt(l.prix_unitaire)}</td>
                  <td className="p-2">{(l.taxe ?? 0).toLocaleString()} {reservation.devise || 'XOF'}</td>
                  <td className="p-2">{fmt(l.total_ligne)}</td>
                </tr>
              ))}
              {(!reservation.lignes || reservation.lignes.length === 0) && (
                <tr><td className="p-3 text-gray-500" colSpan={6}>Aucune ligne</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Timeline simple */}
      <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white dark:bg-panel p-4">
        <div className="flex items-center gap-2 mb-2"><CalendarClock size={16}/> <div className="text-sm font-semibold">Timeline</div></div>
        <div className="text-xs md:text-sm space-y-1">
          <div className="flex items-center gap-2"><Clock size={14}/> Création : {date}</div>
          <div className="flex items-center gap-2"><BadgeCheck size={14}/> Statut : {reservation.statut || 'brouillon'}</div>
        </div>
      </div>

      {reservation.notes && (
        <div className="rounded-2xl border border-black/5 dark:border-white/10 bg-white dark:bg-panel p-4">
          <div className="text-sm font-semibold mb-1">Notes</div>
          <div className="text-sm whitespace-pre-wrap">{reservation.notes}</div>
        </div>
      )}
    </div>
  )
}

export default ReservationDetails
